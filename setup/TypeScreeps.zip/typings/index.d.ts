/// <reference path="globals/lodash/index.d.ts" />
/// <reference path="globals/node/index.d.ts" />
/// <reference path="globals/screeps/index.d.ts" />
/// <reference path="modules/tapable/index.d.ts" />
/// <reference path="modules/webpack-chain/index.d.ts" />
/// <reference path="modules/webpack/index.d.ts" />
