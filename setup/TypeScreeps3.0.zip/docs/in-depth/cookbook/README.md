# Cookbook

This section contains a community-maintained list of slightly more advanced tips and tricks to help better improve your Screeps AI development workflow with TypeScript. Feel free to [contribute your own](https://github.com/screepers/screeps-typescript-starter/tree/master/docs)!

