export const Game = {
  creeps: [],
  rooms: [],
  spawns: {},
  time: 12345
};

export const Memory = {
  creeps: []
};
